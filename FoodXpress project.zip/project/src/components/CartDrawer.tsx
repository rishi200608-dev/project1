import { useEffect, useState } from 'react';
import { useCart } from '../context/CartContext';
import { useNav } from '../context/NavContext';
import { supabase } from '../lib/supabase';
import type { SavedAddress } from '../lib/savedAddresses';
import {
  X, Plus, Minus, ShoppingBag, IndianRupee, MapPin, CheckCircle2, Loader2,
  Home, Briefcase, MapPinned, CreditCard, Wallet, Banknote, Smartphone,
  ChevronDown, Trash2, Plus as PlusIcon,
} from 'lucide-react';
import { VegBadge } from './RestaurantCard';

type PaymentMode = 'upi' | 'card' | 'wallet' | 'cod';

const PAYMENT_OPTIONS: { id: PaymentMode; label: string; desc: string; icon: typeof CreditCard }[] = [
  { id: 'upi', label: 'UPI', desc: 'Google Pay, PhonePe, Paytm', icon: Smartphone },
  { id: 'card', label: 'Credit/Debit Card', desc: 'Visa, Mastercard, RuPay', icon: CreditCard },
  { id: 'wallet', label: 'FoodXpress Wallet', desc: 'Balance: ₹500', icon: Wallet },
  { id: 'cod', label: 'Cash on Delivery', desc: 'Pay when you receive', icon: Banknote },
];

const LABEL_ICONS: Record<string, typeof Home> = {
  Home: Home,
  Work: Briefcase,
  Other: MapPinned,
};

export function CartDrawer() {
  const { items, isOpen, setOpen, updateQuantity, clearCart, subtotal, totalItems, restaurantId } = useCart();
  const { navigate } = useNav();

  const [addresses, setAddresses] = useState<SavedAddress[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(null);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [showPaymentSection, setShowPaymentSection] = useState(false);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('upi');
  const [placing, setPlacing] = useState(false);

  // Form state
  const [label, setLabel] = useState('Home');
  const [fullAddress, setFullAddress] = useState('');
  const [city, setCity] = useState('Hyderabad');
  const [pincode, setPincode] = useState('');
  const [savingAddress, setSavingAddress] = useState(false);

  useEffect(() => {
    if (isOpen) loadAddresses();
  }, [isOpen]);

  const loadAddresses = async () => {
    const { data } = await supabase.from('saved_addresses').select('*').order('created_at', { ascending: false });
    setAddresses(data || []);
    const defaultAddr = (data || []).find((a) => a.is_default) || (data || [])[0];
    if (defaultAddr) setSelectedAddressId(defaultAddr.id);
  };

  const handleSaveAddress = async () => {
    if (!fullAddress.trim()) return;
    setSavingAddress(true);
    const { data } = await supabase
      .from('saved_addresses')
      .insert({ label, full_address: fullAddress, city, pincode, is_default: addresses.length === 0 })
      .select()
      .maybeSingle();

    if (data) {
      setAddresses((prev) => [data, ...prev]);
      setSelectedAddressId(data.id);
    }
    setFullAddress('');
    setPincode('');
    setLabel('Home');
    setShowAddressForm(false);
    setSavingAddress(false);
  };

  const handleDeleteAddress = async (id: string) => {
    await supabase.from('saved_addresses').delete().eq('id', id);
    setAddresses((prev) => prev.filter((a) => a.id !== id));
    if (selectedAddressId === id) setSelectedAddressId(addresses.find((a) => a.id !== id)?.id || null);
  };

  const selectedAddress = addresses.find((a) => a.id === selectedAddressId);

  const deliveryFee = subtotal > 0 ? (subtotal > 199 ? 0 : 25) : 0;
  const taxes = Math.round(subtotal * 0.05);
  const total = subtotal + deliveryFee + taxes;

  const handlePlaceOrder = async () => {
    if (!restaurantId || !selectedAddress || items.length === 0) return;
    setPlacing(true);

    const restRes = await supabase
      .from('restaurants')
      .select('name')
      .eq('id', restaurantId)
      .maybeSingle();
    const restaurantName = restRes.data?.name || 'Restaurant';

    const fullAddr = `${selectedAddress.label}: ${selectedAddress.full_address}, ${selectedAddress.city}${selectedAddress.pincode ? ' - ' + selectedAddress.pincode : ''}`;

    const { data: order, error } = await supabase
      .from('orders')
      .insert({
        restaurant_id: restaurantId,
        restaurant_name: restaurantName,
        total,
        status: 'Placed',
        address: fullAddr,
      })
      .select()
      .maybeSingle();

    if (error || !order) {
      setPlacing(false);
      alert('Failed to place order. Please try again.');
      return;
    }

    const orderItems = items.map((i) => ({
      order_id: order.id,
      menu_item_id: i.id,
      name: i.name,
      price: i.price,
      quantity: i.quantity,
      is_veg: i.is_veg,
    }));

    await supabase.from('order_items').insert(orderItems);

    clearCart();
    setPlacing(false);
    setOpen(false);
    setShowPaymentSection(false);
    navigate({ name: 'order-success', orderId: order.id });
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/50 transition-opacity animate-fade-in"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Drawer */}
      <div
        className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col bg-white shadow-2xl transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 p-4">
          <h2 className="text-lg font-bold text-slate-800">
            {totalItems > 0 ? `Cart (${totalItems})` : 'Your Cart'}
          </h2>
          <button
            onClick={() => {
              setOpen(false);
              setShowPaymentSection(false);
            }}
            className="rounded-full p-1.5 text-slate-500 transition-colors hover:bg-slate-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-slate-100">
              <ShoppingBag className="h-10 w-10 text-slate-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-700">Your cart is empty</h3>
              <p className="mt-1 text-sm text-slate-500">
                Add some delicious food to get started!
              </p>
            </div>
            <button
              onClick={() => {
                setOpen(false);
                navigate({ name: 'home' });
              }}
              className="rounded-lg bg-orange-500 px-6 py-2.5 text-sm font-bold text-white transition-colors hover:bg-orange-600"
            >
              Browse Restaurants
            </button>
          </div>
        ) : !showPaymentSection ? (
          <>
            {/* Items + Address */}
            <div className="flex-1 overflow-y-auto p-4">
              {/* Items */}
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex animate-fade-in-up items-center gap-3">
                    <VegBadge isVeg={item.is_veg} />
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-slate-800">{item.name}</h4>
                      <span className="text-sm text-slate-500">₹{item.price}</span>
                    </div>
                    <div className="flex items-center gap-1.5 rounded-lg border-2 border-orange-400 bg-white">
                      <button
                        onClick={() => updateQuantity(item.id, -1)}
                        className="p-1 text-orange-500 transition-colors hover:bg-orange-50"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="min-w-[18px] text-center text-sm font-bold text-orange-500">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, 1)}
                        className="p-1 text-orange-500 transition-colors hover:bg-orange-50"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <span className="w-16 text-right text-sm font-bold text-slate-700">
                      ₹{item.price * item.quantity}
                    </span>
                  </div>
                ))}
              </div>

              {/* Address section */}
              <div className="mt-6">
                <label className="flex items-center gap-1.5 text-sm font-bold text-slate-700">
                  <MapPin className="h-4 w-4 text-orange-500" />
                  Delivery Address
                </label>

                {/* Saved addresses */}
                {addresses.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {addresses.map((addr) => {
                      const Icon = LABEL_ICONS[addr.label] || MapPinned;
                      const isSelected = selectedAddressId === addr.id;
                      return (
                        <div
                          key={addr.id}
                          className={`group flex cursor-pointer items-start gap-3 rounded-xl border-2 p-3 transition-all ${
                            isSelected
                              ? 'border-orange-400 bg-orange-50'
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                          onClick={() => setSelectedAddressId(addr.id)}
                        >
                          <div className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg ${isSelected ? 'bg-orange-500 text-white' : 'bg-slate-100 text-slate-500'}`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-slate-800">{addr.label}</span>
                              {addr.is_default && (
                                <span className="rounded bg-green-100 px-1.5 py-0.5 text-[10px] font-semibold text-green-700">
                                  Default
                                </span>
                              )}
                            </div>
                            <p className="mt-0.5 text-xs text-slate-500">
                              {addr.full_address}, {addr.city}{addr.pincode ? ' - ' + addr.pincode : ''}
                            </p>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteAddress(addr.id);
                            }}
                            className="flex-shrink-0 rounded p-1 text-slate-300 transition-colors hover:text-red-500"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Add new address form */}
                {showAddressForm ? (
                  <div className="mt-3 animate-scale-in rounded-xl border-2 border-dashed border-orange-300 bg-orange-50/50 p-4">
                    <div className="space-y-3">
                      {/* Label selector */}
                      <div className="flex gap-2">
                        {['Home', 'Work', 'Other'].map((l) => (
                          <button
                            key={l}
                            onClick={() => setLabel(l)}
                            className={`flex items-center gap-1 rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${
                              label === l ? 'bg-orange-500 text-white' : 'bg-white text-slate-600 hover:bg-orange-100'
                            }`}
                          >
                            {l}
                          </button>
                        ))}
                      </div>
                      <textarea
                        value={fullAddress}
                        onChange={(e) => setFullAddress(e.target.value)}
                        placeholder="Enter full address (house no, street, area)"
                        rows={2}
                        className="w-full rounded-lg border border-slate-200 bg-white p-3 text-sm text-slate-700 outline-none focus:border-orange-400"
                      />
                      <div className="flex gap-2">
                        <input
                          value={city}
                          onChange={(e) => setCity(e.target.value)}
                          placeholder="City"
                          className="flex-1 rounded-lg border border-slate-200 bg-white p-2.5 text-sm text-slate-700 outline-none focus:border-orange-400"
                        />
                        <input
                          value={pincode}
                          onChange={(e) => setPincode(e.target.value)}
                          placeholder="Pincode"
                          maxLength={6}
                          className="w-28 rounded-lg border border-slate-200 bg-white p-2.5 text-sm text-slate-700 outline-none focus:border-orange-400"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={handleSaveAddress}
                          disabled={!fullAddress.trim() || savingAddress}
                          className="flex-1 rounded-lg bg-orange-500 py-2.5 text-sm font-bold text-white transition-colors hover:bg-orange-600 disabled:opacity-50"
                        >
                          {savingAddress ? 'Saving...' : 'Save Address'}
                        </button>
                        <button
                          onClick={() => setShowAddressForm(false)}
                          className="rounded-lg bg-slate-100 px-4 py-2.5 text-sm font-bold text-slate-600 transition-colors hover:bg-slate-200"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowAddressForm(true)}
                    className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-300 py-3 text-sm font-semibold text-slate-500 transition-colors hover:border-orange-400 hover:text-orange-500"
                  >
                    <PlusIcon className="h-4 w-4" />
                    Add New Address
                  </button>
                )}
              </div>
            </div>

            {/* Bill details */}
            <div className="border-t border-slate-100 p-4">
              <h3 className="mb-3 text-sm font-bold text-slate-800">Bill Details</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-slate-600">
                  <span>Item Total</span>
                  <span className="flex items-center">
                    <IndianRupee className="h-3.5 w-3.5" />
                    {subtotal}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Delivery Fee</span>
                  <span className={deliveryFee === 0 ? 'font-semibold text-green-600' : ''}>
                    {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Taxes & Charges (5%)</span>
                  <span className="flex items-center">
                    <IndianRupee className="h-3.5 w-3.5" />
                    {taxes}
                  </span>
                </div>
                <div className="flex justify-between border-t border-dashed border-slate-200 pt-2 font-bold text-slate-800">
                  <span>To Pay</span>
                  <span className="flex items-center">
                    <IndianRupee className="h-4 w-4" />
                    {total}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setShowPaymentSection(true)}
                disabled={!selectedAddress}
                className="mt-4 flex w-full items-center justify-between rounded-xl bg-orange-500 py-3 text-base font-bold text-white shadow-lg transition-colors hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <span>Proceed to Pay</span>
                <span className="flex items-center">
                  ₹{total}
                  <ChevronDown className="h-5 w-5 -rotate-90" />
                </span>
              </button>
              {!selectedAddress && (
                <p className="mt-2 text-center text-xs text-red-500">
                  Please add or select a delivery address
                </p>
              )}
            </div>
          </>
        ) : (
          <>
            {/* Payment section */}
            <div className="flex-1 overflow-y-auto p-4">
              {/* Back button */}
              <button
                onClick={() => setShowPaymentSection(false)}
                className="mb-4 flex items-center gap-1 text-sm font-semibold text-slate-600 transition-colors hover:text-orange-500"
              >
                <ChevronDown className="h-4 w-4 rotate-90" />
                Back to Cart
              </button>

              {/* Selected address summary */}
              {selectedAddress && (
                <div className="mb-4 rounded-xl bg-slate-50 p-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="mt-0.5 h-4 w-4 flex-shrink-0 text-orange-500" />
                    <div>
                      <span className="text-sm font-bold text-slate-800">{selectedAddress.label}</span>
                      <p className="text-xs text-slate-500">
                        {selectedAddress.full_address}, {selectedAddress.city}{selectedAddress.pincode ? ' - ' + selectedAddress.pincode : ''}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Payment modes */}
              <h3 className="mb-3 text-sm font-bold text-slate-800">Select Payment Mode</h3>
              <div className="space-y-2">
                {PAYMENT_OPTIONS.map((opt) => {
                  const Icon = opt.icon;
                  const isSelected = paymentMode === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => setPaymentMode(opt.id)}
                      className={`flex w-full items-center gap-3 rounded-xl border-2 p-3.5 transition-all animate-fade-in-up ${
                        isSelected
                          ? 'border-orange-400 bg-orange-50 shadow-sm'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className={`flex h-10 w-10 items-center justify-center rounded-lg transition-colors ${isSelected ? 'bg-orange-500 text-white' : 'bg-slate-100 text-slate-500'}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-bold text-slate-800">{opt.label}</p>
                        <p className="text-xs text-slate-500">{opt.desc}</p>
                      </div>
                      <div className={`h-5 w-5 rounded-full border-2 transition-all ${isSelected ? 'border-orange-500 bg-orange-500' : 'border-slate-300'}`}>
                        {isSelected && <CheckCircle2 className="h-full w-full text-white" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Bill summary */}
              <div className="mt-6 rounded-xl bg-slate-50 p-4">
                <h3 className="mb-3 text-sm font-bold text-slate-800">Bill Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-slate-600">
                    <span>Item Total</span>
                    <span>₹{subtotal}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Delivery Fee</span>
                    <span className={deliveryFee === 0 ? 'font-semibold text-green-600' : ''}>
                      {deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Taxes & Charges (5%)</span>
                    <span>₹{taxes}</span>
                  </div>
                  <div className="flex justify-between border-t border-dashed border-slate-200 pt-2 font-bold text-slate-800">
                    <span>To Pay</span>
                    <span>₹{total}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Place order */}
            <div className="border-t border-slate-100 p-4">
              <button
                onClick={handlePlaceOrder}
                disabled={placing}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-orange-500 py-3 text-base font-bold text-white shadow-lg transition-all hover:bg-orange-600 hover:shadow-xl disabled:opacity-60"
              >
                {placing ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Placing Order...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-5 w-5" />
                    Place Order • ₹{total}
                  </>
                )}
              </button>
              <p className="mt-2 text-center text-xs text-slate-400">
                Pay via {PAYMENT_OPTIONS.find((p) => p.id === paymentMode)?.label}
              </p>
            </div>
          </>
        )}
      </div>
    </>
  );
}
